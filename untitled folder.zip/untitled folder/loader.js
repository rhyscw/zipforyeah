const startButton = document.getElementById("start")
const startStatus = document.getElementById("status")

// Tiny localStorage wrapper (private mode / blocked storage must never throw)
const store = {
  get(key) { try { return localStorage.getItem(key) } catch (error) { return null } },
  set(key, value) { try { localStorage.setItem(key, value) } catch (error) {} },
  del(key) { try { localStorage.removeItem(key) } catch (error) {} }
}
const MT_FAILED = "mcsm-mt-failed"     // threaded build failed on this device (timestamp)
const MT_ATTEMPT = "mcsm-mt-attempt"   // set while a threaded start is in flight; survives only if the tab was killed

function fail(error) {
  const text = error && (error.stack || error.message) || String(error)
  console.error(text)
  startStatus.textContent = error && error.message || text
}

function readU16(view, offset) {
  return view.getUint16(offset, true)
}

function readU32(view, offset) {
  return view.getUint32(offset, true)
}

function mapPe(bytes, heap) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const peOffset = readU32(view, 0x3c)
  const sectionCount = readU16(view, peOffset + 6)
  const optionalSize = readU16(view, peOffset + 20)
  const optionalOffset = peOffset + 24
  const imageBase = readU32(view, optionalOffset + 28)
  const headerSize = readU32(view, optionalOffset + 60)
  heap.set(bytes.subarray(0, headerSize), imageBase)
  const sectionTable = optionalOffset + optionalSize
  for (let index = 0; index < sectionCount; index += 1) {
    const entry = sectionTable + index * 40
    const virtualAddress = readU32(view, entry + 12)
    const rawSize = readU32(view, entry + 16)
    const rawOffset = readU32(view, entry + 20)
    if (rawSize) heap.set(bytes.subarray(rawOffset, rawOffset + rawSize), imageBase + virtualAddress)
  }
}

globalThis.MCSMShaderPairs = (() => {
  const key = "mcsm-shader-pairs-1"
  const known = new Set()
  const absorb = text => { for (let at = 0; at + 32 <= text.length; at += 32) { const pair = text.slice(at, at + 32); if (/^[0-9a-f]{32}$/.test(pair)) known.add(pair) } }
  try { absorb(localStorage.getItem(key) || "") } catch (error) {}
  let timer = 0
  const save = () => { timer = 0; try { localStorage.setItem(key, Array.from(known).slice(-60000).join("")) } catch (error) {} }
  return {
    known,
    add(pair) {
      if (known.has(pair)) return
      known.add(pair)
      if (!timer) timer = setTimeout(save, 5000)
    }
  }
})()

const DEFAULT_WINDOW_SIZE = 0xD895A4

const importsRequest = fetch("imports.json")
const audioReady = MCSMFmod.load()
const filesReady = MCSMFiles.init()
const exeRequest = filesReady.then(() => MCSMFiles.whole("MinecraftStoryMode.exe"))
for (const request of [importsRequest, audioReady, filesReady, exeRequest]) request.catch(() => {})

async function prepare() {
  await filesReady
  await audioReady
  const [bytes, importsResponse] = await Promise.all([exeRequest, importsRequest])
  if (!importsResponse.ok) throw new Error(`Import manifest failed: ${importsResponse.status}`)
  const imports = await importsResponse.json()
  MCSMFmod.bind(imports)
  mapPe(bytes, Module.HEAPU8)
  const memoryView = new DataView(Module.HEAPU8.buffer)
  for (const item of imports) memoryView.setUint32(item.iat, item.token, true)
  const config = globalThis.MCSMConfig || {render: [1920, 1080], output: [1920, 1080], antialias: 1, anisotropy: 16}
  Module.mcsmRenderWidth = config.render[0]
  Module.mcsmRenderHeight = config.render[1]
  memoryView.setFloat32(DEFAULT_WINDOW_SIZE, config.render[0], true)
  memoryView.setFloat32(DEFAULT_WINDOW_SIZE + 4, config.render[1], true)
  if (Module._mcsm_set_render_size) Module._mcsm_set_render_size(config.render[0], config.render[1])
  if (Module._mcsm_set_output) Module._mcsm_set_output(config.output[0], config.output[1], config.antialias)
  if (Module._mcsm_set_anisotropy) Module._mcsm_set_anisotropy(config.anisotropy)
  const query = new URLSearchParams(location.search)
  if (Module._mcsm_set_half_pixel && query.get("halfpixel") === "0") Module._mcsm_set_half_pixel(0)
  if (Module._mcsm_set_fix_flags) Module._mcsm_set_fix_flags(query.has("fix") ? Number(query.get("fix")) >>> 0 : 2154689 | (config.shadows ? 526 : 4390912))
  if (Module._mcsm_set_slice && query.has("slice")) Module._mcsm_set_slice(Number(query.get("slice")))
  if (Module._mcsm_set_clip_mode && query.has("clip")) Module._mcsm_set_clip_mode(Number(query.get("clip")))
  Module._mcsm_runtime_init()
  for (const entry of MCSMFiles.entries.values()) {
    if (!entry.bytes || entry.dynamic) continue
    const name = entry.path.split("/").pop()
    const namePointer = Module._malloc(name.length + 1)
    const dataPointer = Module._malloc(entry.bytes.length)
    if (!namePointer || !dataPointer) {
      if (namePointer) Module._free(namePointer)
      throw new Error("Out of memory while loading game files. Close other tabs/apps, or lower Quality, and reload.")
    }
    Module.HEAPU8.set(new TextEncoder().encode(name + "\0"), namePointer)
    Module.HEAPU8.set(entry.bytes, dataPointer)
    Module._mcsm_register_preloaded_file(namePointer, dataPointer, entry.bytes.length)
    Module._free(namePointer)
  }
  startButton.disabled = false
  startStatus.textContent = "Click to start"
  store.del(MT_ATTEMPT)
}

var Module = {
  canvas: document.getElementById("canvas"),
  mcsmUncapped: new URLSearchParams(location.search).has("uncapped") || !!(globalThis.MCSMConfig && MCSMConfig.settings && MCSMConfig.settings.fps === "uncapped"),
  mcsmGpuPace: new URLSearchParams(location.search).has("gpupace") ? Number(new URLSearchParams(location.search).get("gpupace")) : 1,
  onRuntimeInitialized() {
    Module.mcsmReady = true
    prepare().catch(fail)
  }
}

const WINDOWED_FLAG = 0xDD3D8D

function luaRun(code, match = /^(?!@)/, repeat = false) {
  (globalThis.mcsmLuaInject = globalThis.mcsmLuaInject || []).push({match, code, prepend: true, quiet: true, repeat})
}

luaRun(`if Menu_Add and Menu_Add ~= mcsmMenuAdd then
  local add = Menu_Add
  local removed = {["Main_AccountLink()"] = true, ["Menu_AccountSettings()"] = true, ["Menu_Main_Stats()"] = true, ["Menu_Main_Exit()"] = true}
  local nothing = function() end
  local absent = setmetatable({}, {__index = function() return nothing end, __newindex = nothing})
  mcsmMenuAdd = function(...)
    local command = select(4, ...)
    if command and removed[command] then return absent end
    return add(...)
  end
  Menu_Add = mcsmMenuAdd
end`, /^Menu_Main_Start\(\)/, true)

luaRun(`if UI_Notify and ThreadStart then ThreadStart(function()
  Sleep(1)
  ThreadStart(function()
    for attempt = 1, 600 do
      local found = {}
      local listed, agents = pcall(SceneGetAgents, "ui_popup.scene")
      if listed and agents then
        for _, agent in ipairs(agents) do found[AgentGetName(agent)] = agent end
      end
      local window, button, face, header, message = found.ui_popup_window, found.ui_popup_button1, found.ui_popup_button1_button, found.ui_popup_header, found.ui_popup_message
      if window and button and face and header and message and AgentGetPos(button).y < -0.5 then
        local saved = {}
        local set = function(agent, key, value)
          saved[#saved + 1] = {agent, key, AgentGetProperty(agent, key)}
          AgentSetProperty(agent, key, value)
        end
        local move = function(agent, x, y)
          local place = AgentGetPos(agent)
          saved[#saved + 1] = {agent, false, Vector(place.x, place.y, place.z)}
          AgentSetPos(agent, Vector(x, y, place.z))
        end
        set(window, "Render Global Scale", 0.66)
        set(window, "Render Axis Scale", Vector(1, 1.105, 1))
        move(button, -0.03, -1.172)
        set(face, "Render Axis Scale", Vector(0.66, 0.78, 1))
        set(header, "Text Scale", 1.15)
        set(header, "Text Alignment Horizontal", 2)
        set(header, "Text Color", Color(0.2, 0.2, 0.2, 1))
        move(header, -0.03, 1.149)
        set(message, "Text Scale", 1.15)
        set(message, "Text Alignment Horizontal", 2)
        set(message, "Text Color", Color(0.29, 0.29, 0.29, 1))
        move(message, -0.03, 0.759)
        local show = Popup
        Popup = function(...)
          Popup = show
          pcall(function()
            for index = #saved, 1, -1 do
              local item = saved[index]
              if item[2] then AgentSetProperty(item[1], item[2], item[3]) else AgentSetPos(item[1], item[3]) end
            end
          end)
          return show(...)
        end
        return
      end
      WaitForNextFrame()
    end
  end)
  UI_Notify("Before you play", "This is an early version of\\nMinecraft: Story Mode in web.\\nThere WILL be bugs and\\nperformance issues.")
end) end`, /^Menu_Main_Start\(\)/)
luaRun("if Settings_Set and not mcsmWindowedHook then mcsmWindowedHook = true local original = Settings_Set Settings_Set = function(key, value, ...) local result = original(key, value, ...) if key == 'Windowed' and IsFullScreen() == (value and true or false) then FullScreen(not value) end return result end end", /^Menu_Main_Start\(\)/)
luaRun("if Settings_Set and not mcsmWindowedHook then mcsmWindowedHook = true local original = Settings_Set Settings_Set = function(key, value, ...) local result = original(key, value, ...) if key == 'Windowed' and IsFullScreen() == (value and true or false) then FullScreen(not value) end return result end end", /^Menu_Options\(\)/)
luaRun("if Settings_Set and not mcsmWindowedHook then mcsmWindowedHook = true local original = Settings_Set Settings_Set = function(key, value, ...) local result = original(key, value, ...) if key == 'Windowed' and IsFullScreen() == (value and true or false) then FullScreen(not value) end return result end end", /^Menu_Graphics\(\)/)

function syncFullscreen() {
  let previous = null
  const browserFullscreen = () => !!(document.fullscreenElement || document.webkitFullscreenElement)
  const enter = () => {
    const root = document.documentElement
    const request = root.requestFullscreen || root.webkitRequestFullscreen
    if (!request) return Promise.reject(new Error("fullscreen unsupported"))
    return Promise.resolve(request.call(root, {navigationUI: "hide"}))
  }
  const leave = () => {
    const exit = document.exitFullscreen || document.webkitExitFullscreen
    if (exit && browserFullscreen()) Promise.resolve(exit.call(document)).catch(() => {})
  }
  let aspect = 0
  const tick = () => {
    const canvas = Module.canvas
    if (canvas.width && canvas.height && canvas.width / canvas.height !== aspect) {
      aspect = canvas.width / canvas.height
      canvas.style.setProperty("--aspect", String(aspect))
    }
    const heap = Module.HEAPU8
    if (heap) {
      const windowed = heap[WINDOWED_FLAG]
      if (previous === null) {
        if (!windowed && !browserFullscreen()) heap[WINDOWED_FLAG] = 1
        previous = heap[WINDOWED_FLAG]
      } else if (windowed !== previous) {
        previous = windowed
        if (!windowed && !browserFullscreen()) enter().catch(() => { Module.HEAPU8[WINDOWED_FLAG] = 1; previous = 1 })
        else if (windowed) leave()
      }
    }
    requestAnimationFrame(tick)
  }
  const changed = () => {
    const heap = Module.HEAPU8
    if (!heap) return
    if (!browserFullscreen() && !heap[WINDOWED_FLAG]) {
      luaRun("if IsFullScreen() then FullScreen(false) end")
      setTimeout(() => { if (!browserFullscreen() && !Module.HEAPU8[WINDOWED_FLAG]) { Module.HEAPU8[WINDOWED_FLAG] = 1; previous = 1 } }, 3000)
    }
    Module.canvas.focus()
  }
  document.addEventListener("fullscreenchange", changed)
  document.addEventListener("webkitfullscreenchange", changed)
  requestAnimationFrame(tick)
}

startButton.addEventListener("click", async () => {
  startButton.disabled = true
  startButton.classList.add("hidden")
  const optionsPanel = document.getElementById("options")
  if (optionsPanel) optionsPanel.classList.add("hidden")
  Module.canvas.focus()
  syncFullscreen()
  try {
    if (Module._mcsm_mt_start) {
      const hosting = new URLSearchParams(location.search).get("mt") || ""
      Module._mcsm_mt_options(hosting === "main" || hosting === "first" ? 1 : 0, hosting === "main" || hosting === "jobs" ? 1 : 0)
      await Module.ccall("mcsm_mt_start", null, [], [], {async: true})
    } else await Module.ccall("xbe_entry_point", null, [], [], {async: true})
  } catch (error) {
    if (Module._mcsm_dump_ring) Module._mcsm_dump_ring()
    fail(error)
  }
})

const jspiSupported = typeof WebAssembly.Suspending === "function" && typeof WebAssembly.promising === "function"
const buildQuery = new URLSearchParams(location.search)
const singleBuild = jspiSupported ? "mcsm_r4" : "mcsm"
const threadCapable = jspiSupported && globalThis.crossOriginIsolated === true && typeof SharedArrayBuffer === "function" && (navigator.hardwareConcurrency || 1) >= 2
const pickerSettings = (globalThis.MCSMConfig && MCSMConfig.settings) || {quality: "auto", fps: "60", aa: "smooth", shadows: "auto", threads: "on"}
const threadsAvailable = threadCapable

// The threaded wasm hard-requires 1792 MB of shared memory (min = max), plus a worker pool.
// navigator.deviceMemory (Chromium only) is rounded and capped at 8, so "8" means "8 GB or more".
// Browsers that don't report it (Firefox/Safari) fall through to the crash/timeout detection below.
const MIN_MT_MEMORY_GB = 8
const deviceMemory = navigator.deviceMemory || 0
const lowMemory = deviceMemory > 0 && deviceMemory < MIN_MT_MEMORY_GB

// A previous threaded start that never finished and never fired "pagehide" means the tab was killed (usually out of memory).
if (store.get(MT_ATTEMPT)) { store.set(MT_FAILED, String(Date.now())); store.del(MT_ATTEMPT) }
const recentlyFailed = Date.now() - (Number(store.get(MT_FAILED)) || 0) < 7 * 24 * 3600 * 1000
const threadsAuto = threadCapable && !lowMemory && !recentlyFailed

let buildName = buildQuery.get("build") || (pickerSettings.threads !== "off" && threadsAuto ? "mcsm_mt" : singleBuild)
if (buildName.startsWith("mcsm_mt") && !threadCapable) buildName = singleBuild
if (buildName.startsWith("mcsm_mt")) {
  const reported = Number(buildQuery.get("cores")) || Math.min(4, (navigator.hardwareConcurrency || 2) - 2)
  Module.mcsmWorkers = 1 + 5 * Math.max(1, Math.min(8, reported))
  store.set(MT_ATTEMPT, String(Date.now()))
  addEventListener("pagehide", () => store.del(MT_ATTEMPT))
}

let leavingThreadedBuild = false
function leaveThreadedBuild(reason) {
  if (!buildName.startsWith("mcsm_mt") || Module.mcsmReady || leavingThreadedBuild) return
  leavingThreadedBuild = true
  const url = new URL(location.href)
  console.error(`[loader] threaded build failed to start (${reason}); reloading with ${singleBuild}`)
  store.set(MT_FAILED, String(Date.now()))
  store.del(MT_ATTEMPT)
  startStatus.textContent = "Switching to compatibility mode…"
  url.searchParams.set("build", singleBuild)
  history.replaceState(Object.assign({}, history.state, {mcsm: Object.assign({}, pickerSettings, {threads: "off"})}), "", url.href)
  location.reload()
}

Module.onAbort = reason => {
  if (buildName.startsWith("mcsm_mt") && !Module.mcsmReady) leaveThreadedBuild(String(reason))
  else fail(new Error(/memory|grow|alloc/i.test(String(reason)) ? "Out of memory. Close other tabs/apps, or lower Quality, and reload." : String(reason)))
}
addEventListener("error", event => { if (String(event.filename || "").includes(`/${buildName}.`)) leaveThreadedBuild(event.message) })

// Watchdog: a worker pool that never comes up fails silently. If the threaded runtime isn't ready and
// nothing has been downloaded for 20 s, give up and use the single-threaded build.
if (buildName.startsWith("mcsm_mt")) {
  const watchdog = setInterval(() => {
    if (Module.mcsmReady) return clearInterval(watchdog)
    if (!globalThis.MCSMProgress) return clearInterval(watchdog)
    if (performance.now() - MCSMProgress.lastActivity > 20000) { clearInterval(watchdog); leaveThreadedBuild("startup stalled") }
  }, 2000)
}

function setupPicker() {
  const panel = document.getElementById("options")
  if (!panel) return
  const config = globalThis.MCSMConfig || {}
  const labels = {auto: config.detected ? `Auto (${config.detected.tier})` : "Auto", "4k": "4K (3840x2160)", ultra: "Ultra (1440p to 1080p)", high: "High (1080p)", medium: "Medium (900p)", low: "Low (720p)", minimum: "Minimum (540p)"}
  const quality = document.getElementById("option-quality")
  for (const [value, text] of Object.entries(labels)) quality.add(new Option(text, value))
  const controlled = {quality: ["quality", "res", "out"], fps: ["uncapped"], aa: ["aa"], shadows: ["shadows"], threads: ["threads", "build"]}
  for (const name of Object.keys(controlled)) {
    const select = document.getElementById(`option-${name}`)
    select.value = pickerSettings[name]
    select.addEventListener("change", () => {
      pickerSettings[name] = select.value
      if (name === "threads") { store.del(MT_FAILED); store.del(MT_ATTEMPT) }
      let saved = true
      try { localStorage.setItem("mcsm-settings", JSON.stringify(pickerSettings)) } catch (error) { saved = false }
      const url = new URL(location.href)
      for (const parameter of controlled[name]) url.searchParams.delete(parameter)
      history.replaceState(Object.assign({}, history.state, {mcsm: saved ? null : pickerSettings}), "", url.href)
      startButton.disabled = true
      startStatus.textContent = "Applying…"
      location.reload()
    })
  }
  const threads = document.getElementById("option-threads")
  if (!threadsAvailable) {
    threads.value = "off"
    threads.disabled = true
    threads.title = "Needs a cross-origin isolated page, JSPI and at least two cores"
  } else if (lowMemory) {
    threads.value = "off"
    threads.disabled = true
    threads.title = "Multithreading needs about 2 GB of free memory; this device reports less. Add ?build=mcsm_mt to the URL to force it."
  } else if (recentlyFailed && !buildQuery.get("build")) {
    threads.value = "off"
    threads.title = "Multithreading failed to start on this device before. Choose On to try again."
  }
}

setupPicker()
const engineScript = document.createElement("script")
engineScript.onerror = () => leaveThreadedBuild("script failed to load")
engineScript.src = `${buildName}.js`
document.body.appendChild(engineScript)
