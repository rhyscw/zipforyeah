// Top-right overlay showing download progress for ANY data download made by the page, including
// partial (Range) streaming while the game runs. It tracks:
//   - fetch() and XMLHttpRequest on the main thread (async and synchronous)
//   - anything reported through MCSMProgress.job(name, total, {demand}) -> {add(bytes), finish()};
//     filesystem.js uses this for downloads that happen inside its Web Worker.
// Audio and images are intentionally not tracked. Must be loaded before filesystem.js / loader.js.
//
// What the overlay shows
//   line 1   Downloading assets .............. N active
//   line 2   <file name> ..................... <batch loaded> / <batch total> MB
//   bar      progress of the current BATCH
//   line 4   <speed> ......................... ~<time> left        (estimate for the current batch only)
//   line 5   Session total ................... <all bytes this page loaded> / <max> MB
// The BATCH is planned work with a known size: whole-file downloads and the background game.data stream.
// On-demand block fetches made while playing are tiny and unpredictable, so they never drive the bar or the
// estimate; if only those are active the overlay says "on demand" and shows speed only.
(() => {
  const nativeFetch = globalThis.fetch && globalThis.fetch.bind(globalThis)
  const MB = 1048576
  const DEMAND_MAX = 4 * MB          // ranged requests up to this size are treated as on-demand block reads
  const FALLBACK_MAX = 6830 * MB     // used until filesystem.js reports the real game.data size
  const state = globalThis.MCSMProgress = {
    lastActivity: performance.now(),
    sessionBytes: 0,
    maxBytes: FALLBACK_MAX,
    setMax(bytes) { if (bytes > 0) { state.maxBytes = bytes; schedulePaint() } }
  }

  const style = document.createElement("style")
  style.textContent = `
#dl-overlay{position:fixed;z-index:2147483000;top:max(12px,env(safe-area-inset-top));right:max(12px,env(safe-area-inset-right));width:270px;max-width:70vw;box-sizing:border-box;padding:8px 12px 9px;border-radius:8px;background:rgba(10,14,24,.78);color:#e6ecfa;font:500 12px/1.3 Rubik,system-ui,sans-serif;pointer-events:none;opacity:0;transform:translateY(-6px);transition:opacity .2s,transform .2s}
#dl-overlay.show{opacity:1;transform:none}
#dl-overlay .row{display:flex;justify-content:space-between;gap:12px;white-space:nowrap}
#dl-overlay .sub{color:#9fb0d0;font-variant-numeric:tabular-nums}
#dl-overlay .name{overflow:hidden;text-overflow:ellipsis;min-width:0}
#dl-overlay .amount{flex:none}
#dl-overlay .bar{margin-top:6px;height:3px;border-radius:2px;background:rgba(255,255,255,.18);overflow:hidden}
#dl-overlay .fill{height:100%;width:0;background:#6fd08c;transition:width .15s}
#dl-overlay.indeterminate .fill{width:35%;animation:dl-slide 1.1s ease-in-out infinite alternate}
#dl-overlay .eta{margin-top:4px}
#dl-overlay .session{margin-top:5px;padding-top:5px;border-top:1px solid rgba(255,255,255,.12);font-size:11px;opacity:.85}
@keyframes dl-slide{from{margin-left:0}to{margin-left:65%}}`
  document.head.appendChild(style)

  const box = document.createElement("div")
  box.id = "dl-overlay"
  box.setAttribute("aria-hidden", "true")
  box.innerHTML = '<div class="row"><span>Downloading assets</span><span class="sub files"></span></div>' +
    '<div class="row sub"><span class="name"></span><span class="amount"></span></div>' +
    '<div class="bar"><div class="fill"></div></div>' +
    '<div class="row sub eta"><span class="speed"></span><span class="left"></span></div>' +
    '<div class="row sub session"><span>Session total</span><span class="sessionAmount"></span></div>'
  document.body.appendChild(box)
  const q = selector => box.querySelector(selector)
  const filesEl = q(".files"), nameEl = q(".name"), amountEl = q(".amount"), fillEl = q(".fill")
  const etaRow = q(".eta"), speedEl = q(".speed"), leftEl = q(".left"), sessionEl = q(".sessionAmount")

  const jobs = new Set()
  let batch, lastMainEnd = 0, hideTimer = 0, resetTimer = 0, staleTimer = 0, painted = false
  const resetBatch = () => { batch = {loaded: 0, knownLoaded: 0, knownTotal: 0, unknown: 0} }
  resetBatch()

  const mb = bytes => bytes >= MB ? (bytes / MB).toFixed(bytes >= 100 * MB ? 0 : 1) + " MB" : Math.max(1, Math.round(bytes / 1024)) + " KB"
  const totalMB = bytes => (bytes / MB).toFixed(bytes < 100 * MB ? 1 : 0)
  const span = seconds => seconds < 60 ? `${Math.max(1, Math.ceil(seconds))}s` : `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`
  const nameOf = url => {
    try { return decodeURIComponent(new URL(String(url), location.href).pathname.split("/").filter(Boolean).pop() || "file") } catch (error) { return "file" }
  }

  // Speed = bytes over the last ~4 s, trusted only with >= 1 s of recent data.
  const samples = []
  function speed() {
    const now = performance.now()
    while (samples.length && now - samples[0][0] > 4000) samples.shift()
    if (samples.length < 2) return 0
    const first = samples[0], last = samples[samples.length - 1]
    if (now - last[0] > 1500 || last[0] - first[0] < 1000) return 0
    return (last[1] - first[1]) / ((last[0] - first[0]) / 1000)
  }

  function paint() {
    painted = false
    let main = 0, demand = 0, latestMain = "", latestAny = ""
    for (const job of jobs) {
      latestAny = job.name
      if (job.demand) demand += 1; else { main += 1; latestMain = job.name }
    }
    filesEl.textContent = jobs.size ? `${jobs.size} active` : "done"
    const label = main ? latestMain : latestAny
    if (label) nameEl.textContent = label

    const rate = jobs.size ? speed() : 0
    const known = batch.unknown === 0 && batch.knownTotal > 0
    let seconds = 0
    if (main || !demand) {
      // The batch: whole-file downloads and the background stream (also what a finished batch shows while lingering).
      amountEl.textContent = known ? `${totalMB(batch.knownLoaded)} / ${totalMB(batch.knownTotal)} MB` : `${totalMB(batch.loaded)} MB`
      if (known) {
        box.classList.remove("indeterminate")
        fillEl.style.width = Math.min(100, batch.knownLoaded / batch.knownTotal * 100) + "%"
      } else {
        box.classList.add("indeterminate")
        fillEl.style.width = ""
      }
      const remaining = batch.knownTotal - batch.knownLoaded
      if (main && known && rate && remaining > 0) seconds = remaining / rate
    } else {
      // Only on-demand block reads are running: nothing planned, so no total and no estimate.
      amountEl.textContent = "on demand"
      box.classList.add("indeterminate")
      fillEl.style.width = ""
    }
    speedEl.textContent = rate ? `${mb(rate)}/s` : ""
    leftEl.textContent = seconds && seconds <= 5400 ? `~${span(seconds)} left` : ""
    etaRow.style.display = speedEl.textContent || leftEl.textContent ? "" : "none"
    sessionEl.textContent = `${totalMB(state.sessionBytes)} / ${Math.round(state.maxBytes / MB)} MB`
  }
  const schedulePaint = () => {
    if (painted) return
    painted = true
    requestAnimationFrame(paint)
  }

  // A request that never completes (a body nobody reads, a dead connection) must not leave the overlay stuck.
  function sweep() {
    const now = performance.now()
    for (const job of jobs) if (now - job.tick > 30000) job.finish()
    if (jobs.size) paint()
  }

  function startJob(url, total, options) {
    total = Number(total) > 0 ? Number(total) : 0
    const demand = !!(options && options.demand)
    const now = performance.now()
    const job = {
      name: nameOf(url), total, demand, counted: 0, finished: false, tick: now,
      add(bytes) {
        if (!(bytes > 0) || job.finished) return
        job.tick = state.lastActivity = performance.now()
        state.sessionBytes += bytes
        samples.push([job.tick, state.sessionBytes])
        if (!demand) {
          batch.loaded += bytes
          if (total) {
            const part = Math.min(bytes, Math.max(0, total - job.counted))
            job.counted += part
            batch.knownLoaded += part
          }
        }
        schedulePaint()
      },
      finish() {
        if (job.finished) return
        job.finished = true
        jobs.delete(job)
        if (!demand) lastMainEnd = performance.now()
        schedulePaint()
        if (jobs.size) return
        clearInterval(staleTimer); staleTimer = 0
        clearTimeout(hideTimer)
        hideTimer = setTimeout(() => {
          if (jobs.size) return
          box.classList.remove("show")
          resetTimer = setTimeout(() => { if (!jobs.size) resetBatch() }, 300)
        }, 1200)
      }
    }
    if (!jobs.size) samples.length = 0 // new burst: don't average in the idle gap before it
    if (!demand) {
      // A new batch starts unless this job directly continues one that only just ended.
      let active = false
      for (const other of jobs) if (!other.demand) active = true
      if (!active && now - lastMainEnd > 1200) resetBatch()
      if (total) batch.knownTotal += total; else batch.unknown += 1
    }
    jobs.add(job)
    clearTimeout(hideTimer); clearTimeout(resetTimer)
    if (!staleTimer) staleTimer = setInterval(sweep, 500)
    // Always visible as soon as any download starts; the 1.2 s linger stops it flickering between requests.
    paint()
    box.classList.add("show")
    return job
  }
  state.job = (name, total, options) => startJob(name, total, options)

  const rangeOf = headers => {
    if (!headers) return false
    try { return !!(typeof headers.get === "function" ? headers.get("Range") : headers.Range || headers.range) } catch (error) { return false }
  }

  // ---- fetch -------------------------------------------------------------------------------------------
  function trackFetch(response, requested, ranged) {
    if (!response.body || !response.ok || typeof ReadableStream !== "function") return response
    // Content-Length of a compressed response doesn't match the decoded bytes we count, so treat it as unknown.
    const encoded = response.headers.get("content-encoding")
    const total = encoded && encoded !== "identity" ? 0 : Number(response.headers.get("content-length")) || 0
    if (total === 1) return response // e.g. a "bytes=0-0" capability probe
    const demand = ranged && total > 0 && total <= DEMAND_MAX
    const job = startJob(response.url || requested, total, {demand})
    const reader = response.body.getReader()
    const body = new ReadableStream({
      async pull(controller) {
        try {
          const {done, value} = await reader.read()
          if (done) { job.finish(); controller.close(); return }
          job.add(value.byteLength)
          controller.enqueue(value)
        } catch (error) {
          job.finish()
          controller.error(error)
        }
      },
      cancel(reason) { job.finish(); return reader.cancel(reason) }
    })
    const wrapped = new Response(body, {status: response.status, statusText: response.statusText, headers: response.headers})
    try { Object.defineProperty(wrapped, "url", {value: response.url}) } catch (error) {}
    return wrapped
  }

  if (nativeFetch) {
    globalThis.fetch = function (input, init) {
      const method = String((init && init.method) || (input && input.method) || "GET").toUpperCase()
      const request = nativeFetch(input, init)
      if (method !== "GET") return request
      const requested = typeof input === "string" ? input : input && (input.url || String(input))
      const ranged = rangeOf(init && init.headers) || rangeOf(input && input.headers)
      return request.then(response => trackFetch(response, requested, ranged))
    }
  }

  // ---- XMLHttpRequest ----------------------------------------------------------------------------------
  if (typeof XMLHttpRequest === "function") {
    const open = XMLHttpRequest.prototype.open
    const send = XMLHttpRequest.prototype.send
    const setHeader = XMLHttpRequest.prototype.setRequestHeader
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this.__dl = {method: String(method).toUpperCase(), url, sync: rest[0] === false, ranged: false}
      return open.call(this, method, url, ...rest)
    }
    XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
      if (this.__dl && String(name).toLowerCase() === "range") this.__dl.ranged = true
      return setHeader.call(this, name, value)
    }
    XMLHttpRequest.prototype.send = function (body) {
      const meta = this.__dl
      if (meta && meta.method === "GET" && meta.sync) {
        // Synchronous XHR (cache-miss block reads) fires no progress events and blocks the page,
        // so account for it once it returns. These are on-demand reads by definition.
        const result = send.call(this, body)
        try {
          const length = this.responseText ? this.responseText.length : 0
          if (length) { const job = startJob(meta.url, length, {demand: true}); job.add(length); job.finish() }
        } catch (error) {}
        return result
      }
      if (meta && meta.method === "GET") {
        let job = null, seen = 0
        this.addEventListener("progress", event => {
          if (!job) {
            let encoded = null
            try { encoded = this.getResponseHeader("content-encoding") } catch (error) {}
            const total = event.lengthComputable && !(encoded && encoded !== "identity") ? event.total : 0
            job = startJob(meta.url, total, {demand: meta.ranged && total > 0 && total <= DEMAND_MAX})
          }
          job.add(event.loaded - seen)
          seen = event.loaded
        })
        this.addEventListener("loadend", () => { if (job) job.finish() })
      }
      return send.call(this, body)
    }
  }
})()
