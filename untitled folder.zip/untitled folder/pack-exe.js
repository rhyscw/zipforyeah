#!/usr/bin/env node
// Usage: node pack-exe.js path/to/game.data [output-dir]
//
// Pulls MinecraftStoryMode.exe out of game.data and writes it, gzipped, as
// MinecraftStoryMode.exe.pack (default: next to game.data). Upload that file beside
// game.data. Re-run it whenever game.data is rebuilt; the loader compares a few samples
// against game.data and quietly ignores a stale .pack, but then you lose the speed-up.

const fs = require("fs")
const path = require("path")
const zlib = require("zlib")

const [input, outDir] = process.argv.slice(2)
if (!input) { console.error("usage: node pack-exe.js path/to/game.data [output-dir]"); process.exit(1) }

const fd = fs.openSync(input, "r")
const read = (position, length) => {
  const buffer = Buffer.alloc(length)
  let got = 0
  while (got < length) {
    const n = fs.readSync(fd, buffer, got, length - got, position + got)
    if (!n) break
    got += n
  }
  return buffer.subarray(0, got)
}

const head = read(0, 32)
if (head.toString("latin1", 0, 8) !== "MCSMDATA" || head.readUInt32LE(8) !== 1) { console.error("not a game.data package this tool understands"); process.exit(1) }
const listed = head.readUInt32LE(16) + head.readUInt32LE(20) * 4294967296
const length = head.readUInt32LE(24)
const index = JSON.parse(read(listed, length).toString("utf8"))

// Same path normalisation the loader uses, so we pick the very entry it will look up.
const normalize = value => {
  let result = value.replace(/\\/g, "/").replace(/^\/{2}\?\//, "").replace(/^[a-z]:(?:\.\/|\/)?/i, "").replace(/^\/+/, "")
  result = result.replace(/^.*?MinecraftStoryMode\//i, "")
  const parts = []
  for (const part of result.split("/")) {
    if (!part || part === ".") continue
    if (part === "..") parts.pop()
    else parts.push(part)
  }
  return parts.join("/").toLowerCase()
}

const entry = index.files.find(file => normalize(file.path) === "minecraftstorymode.exe")
if (!entry) { console.error("MinecraftStoryMode.exe is not in this game.data"); process.exit(1) }

const exe = read(entry.offset, entry.size)
if (exe.length !== entry.size) { console.error("game.data is truncated"); process.exit(1) }

const started = Date.now()
const packed = zlib.gzipSync(exe, {level: 9})
const target = path.join(outDir || path.dirname(input), "MinecraftStoryMode.exe.pack")
fs.mkdirSync(path.dirname(target), {recursive: true})
fs.writeFileSync(target, packed)

const mb = n => (n / 1048576).toFixed(1) + " MB"
console.log(`exe     ${mb(exe.length)}`)
console.log(`packed  ${mb(packed.length)}  (${(100 * packed.length / exe.length).toFixed(0)}% of original, ${((Date.now() - started) / 1000).toFixed(1)}s)`)
console.log(`wrote   ${target}`)
